db.createUser({
  user: "sysadmin",
  pwd: "123qwe",
  roles: [
    {
      role: "readWrite",
      db: "agoradb",
    },
  ],
});
